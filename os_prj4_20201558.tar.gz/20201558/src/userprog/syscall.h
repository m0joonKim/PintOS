#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>

#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
typedef int pid_t;
extern struct lock lockFile;
typedef unsigned mapid_t;
struct mmap_file {            // 구조는 카이스트 pdf참고함
    mapid_t mapid;            // mappingid
    struct file *file;        // mapping file object
    struct list_elem l_elem;  // list elem
    struct list vme_list;     // vmentry list
};
void syscall_init(void);
struct file *getFile(int fd);
void _exit(int status);
int _write(int fd, const void *buffer, unsigned size);
void _halt(void);
int _read(int fd, const void *buffer, unsigned size);
int max_of_four_int(int n1, int n2, int n3, int n4);
int fibonacci(int n);
pid_t _exec(const char *cmd_lisne);
int _wait(pid_t pid);
bool _create(const char *file, unsigned initial_size);
bool _remove(const char *file);
int _open(const char *file);
int _filesize(int fd);
void _seek(int fd, unsigned position);
unsigned _tell(int fd);
void _close(int fd);
mapid_t mmap(int fd, void *addr);
void munmap(mapid_t mapping);
#endif /* userprog/syscall.h */
