#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include <stdbool.h>

#include "threads/thread.h"
#include "vm/vm.h"
tid_t process_execute(const char *file_name);
int process_wait(tid_t);
void process_exit(void);
void process_activate(void);
struct thread *findChild(tid_t pid);
int extraWait(tid_t pid);
bool handle_mm_fault(struct vm_entry *vme);
bool growth_stack(void *esp, void *addr);  // setup_stack에서 modified

#endif /* userprog/process.h */
