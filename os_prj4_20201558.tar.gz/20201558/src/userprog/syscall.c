#include "userprog/syscall.h"

#include <stdlib.h>
static void syscall_handler(struct intr_frame *);
struct lock lockFile;
// 동일한 파일을 여러 fd로 열면 걔네도 막아야하니까
struct file *getFile(int fd) {
    if (fd < 2 || fd >= MAXFD) {
        return NULL;
    }
    return thread_current()->fdList[fd];
}
bool ValidAddressChecker(uint32_t *esp, int argc) {
    if (esp == NULL) return false;
    for (int i = 0; i <= argc; i++) {
        if (!is_user_vaddr((void *)esp + i * 4) || is_kernel_vaddr((void *)esp + i * 4)) {
            return false;
        }
        if (!find_vme(&(thread_current()->vm), (void *)esp + i * 4)) {
            if (!growth_stack((void *)esp + i * 4, esp)) return false;
        }
    }
    return true;
}

void syscall_init(void) {
    lock_init(&(lockFile));
    intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void syscall_handler(struct intr_frame *f UNUSED) {
    uint32_t *SYSNUM = (uint32_t *)f->esp;
    if (!ValidAddressChecker(f->esp, 0)) _exit(-1);
    // printf("\nnow sysnum is %d\n\n", *SYSNUM);
    switch (*SYSNUM) {  // lib/user/syscall.c 보고 대충 구현하기
        case SYS_HALT:
            if (!ValidAddressChecker(f->esp, 0)) _exit(-1);
            _halt();
            break;
        case SYS_EXIT:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            _exit(*(uint32_t *)(f->esp + 4));
            break;
        case SYS_EXEC:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            f->eax = _exec((const char *)*(uint32_t *)(f->esp + 4));
            break;
        case SYS_WAIT:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            f->eax = _wait((pid_t) * (uint32_t *)(f->esp + 4));
            break;
        case SYS_CREATE:
            if (!ValidAddressChecker(f->esp, 2)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _create((const char *)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
            // lock_release(&(lockFile));
            break;
        case SYS_REMOVE:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _remove((const char *)*(uint32_t *)(f->esp + 4));
            // lock_release(&(lockFile));
            break;
        case SYS_OPEN:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _open((const char *)*(uint32_t *)(f->esp + 4));
            // lock_release(&(lockFile));
            break;
        case SYS_FILESIZE:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            f->eax = _filesize((int)*(uint32_t *)(f->esp + 4));
            break;
        case SYS_READ:
            if (!ValidAddressChecker(f->esp, 3)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
            // lock_release(&(lockFile));
            break;
        case SYS_WRITE:
            if (!ValidAddressChecker(f->esp, 3)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
            // lock_release(&(lockFile));
            break;
        case SYS_SEEK:
            if (!ValidAddressChecker(f->esp, 2)) _exit(-1);
            // lock_acquire(&(lockFile));
            _seek((int)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
            // lock_release(&(lockFile));
            break;
        case SYS_TELL:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            // lock_acquire(&(lockFile));
            f->eax = _tell((int)*(uint32_t *)(f->esp + 4));
            // lock_release(&(lockFile));
            break;
        case SYS_CLOSE:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            _close((int)*(uint32_t *)(f->esp + 4));
            break;
        case SYS_FIBONACCI:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            f->eax = fibonacci((int)*(uint32_t *)(f->esp + 4));
            break;
        case SYS_MAXFOUR:
            if (!ValidAddressChecker(f->esp, 4)) _exit(-1);
            f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
            break;
        case SYS_MMAP:
            if (!ValidAddressChecker(f->esp, 2)) _exit(-1);
            f->eax = mmap((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8));
            break;
        case SYS_MUNMAP:
            if (!ValidAddressChecker(f->esp, 1)) _exit(-1);
            munmap((mapid_t) * (uint32_t *)(f->esp + 4));
            break;
        default:
            break;
    }
}
void _halt() { shutdown_power_off(); }
void _exit(int status) {
    struct thread *nowthread = thread_current();
    nowthread->userprogStatus = status;
    printf("%s: exit(%d)\n", thread_name(), status);
    struct list *childL = &(nowthread->childList);
    struct list_elem *nowC = list_begin(childL);
    while (1) {
        if (nowC == list_end(childL)) break;
        _wait(list_entry(nowC, struct thread, childListElem)->tid);
        nowC = list_next(nowC);
    }
    thread_exit();
}
int fibonacci(int n) {
    if (n < 0) {
        printf("[ FIBONACCI ] N must be greater than 0\n");
        _exit(-1);
    }
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }
    if (n == 2) {
        return 1;
    }
    int num1 = 1, num2 = 1, ret;
    for (int i = 3; i <= n; i++) {
        ret = num1 + num2;
        num1 = ret - num1;
        num2 = ret;
    }
    return ret;
}

int max_of_four_int(int n1, int n2, int n3, int n4) {
    int ret = n1;
    if (ret < n2) {
        ret = n2;
    }
    if (ret < n3) {
        ret = n3;
    }
    if (ret < n4) {
        ret = n4;
    }
    return ret;
}
pid_t _exec(const char *cmd_line) {
    // 이름으로부터 PID를 찾을수있음
    if (!is_user_vaddr(cmd_line)) {
        _exit(-1);
    }
    pid_t ret = process_execute(cmd_line);
    if (ret != -1) {
        // sema_down(&(findChild(ret)->semload));
    }
    return ret;
}
int _wait(pid_t pid) {
    int ret = process_wait(pid);
    // printf("wait ret is %d\n", ret);
    return ret;
}
bool _create(const char *fileName, unsigned initial_size) {
    if (!is_user_vaddr(fileName) || !fileName || !sizeof(fileName)) {
        // lock_release(&(lockFile));
        _exit(-1);
    }
    lock_acquire(&(lockFile));
    bool success = filesys_create(fileName, initial_size);
    lock_release(&(lockFile));
    return success;
}
bool _remove(const char *fileName) {
    if (!is_user_vaddr(fileName)) {
        // lock_release(&(lockFile));
        _exit(-1);
    }
    if (fileName == NULL) {
        return false;
    }
    lock_acquire(&(lockFile));
    bool success = filesys_remove(fileName);
    lock_release(&(lockFile));

    return success;
}
int _open(const char *fileName) {
    if (fileName == NULL) {
        return -1;
    }
    lock_acquire(&(lockFile));
    for (int i = 0; i < 20000000; i++);
    struct file *openFile = filesys_open(fileName);
    if (openFile == NULL) {
        lock_release(&(lockFile));
        return -1;
    }  // 실패했으면 -1 return
    int fd = -1;
    struct file **fdL = thread_current()->fdList;
    for (int i = 2; i < 128; i++) {
        if (fdL[i] == NULL) {
            if (!strcmp(fileName, thread_name())) {
                file_deny_write(openFile);
            }
            fdL[i] = openFile;
            fd = i;
            break;
        }
    }
    lock_release(&(lockFile));
    return fd;
}
int _filesize(int fd) {
    lock_acquire(&(lockFile));
    struct file *fdF = getFile(fd);
    if (fdF) {
        int size = file_length(fdF);
        lock_release(&(lockFile));
        return size;
    } else {
        lock_release(&(lockFile));
        _exit(-1);
    }
}

void _seek(int fd, unsigned position) {
    lock_acquire(&(lockFile));

    struct file *fdF = getFile(fd);
    if (fdF) {
        file_seek(fdF, position);
        lock_release(&(lockFile));
        return;
    } else {
        lock_release(&(lockFile));
        _exit(-1);
    }
}
unsigned _tell(int fd) {
    lock_acquire(&(lockFile));
    struct file *fdF = getFile(fd);
    if (fdF) {
        unsigned ret = file_tell(fdF);
        lock_release(&(lockFile));
        return ret;
    } else {
        lock_release(&(lockFile));
        _exit(-1);
    }
    return -1;
}
void _close(int fd) {
    // lock_acquire(&(lockFile));
    struct file *fdF = getFile(fd);
    if (fdF) {
        // 누가 보고있거나 읽고있으면 그건 다 할수있게 해야함..
        // file_allow_write(fdF);
        file_close(fdF);
        thread_current()->fdList[fd] = NULL;
        // lock_release(&(lockFile));
        return;
    }
    // lock_release(&(lockFile));
    return;
}
int _write(int fd, const void *buffer, unsigned size) {
    if (!is_user_vaddr(buffer)) {
        _exit(-1);
    }
    lock_acquire(&(lockFile));

    if (fd == 1) {
        putbuf(buffer, size);
        lock_release(&(lockFile));

        return size;
    } else {
        struct file *fdF = getFile(fd);
        if (!fdF | !is_user_vaddr(buffer)) {
            lock_release(&(lockFile));
            return -1;
        }
        if ((thread_current()->fdList[fd])->deny_write) {
            file_deny_write(thread_current()->fdList[fd]);
        }
        int ret = file_write(fdF, buffer, size);
        lock_release(&(lockFile));

        return ret;
    }
    lock_release(&(lockFile));

    return -1;
}
int _read(int fd, const void *buffer, unsigned size) {
    if (!is_user_vaddr(buffer)) {
        _exit(-1);
    }
    unsigned int realSize = 0;
    lock_acquire(&(lockFile));
    if (fd == 0) {
        for (realSize = 0; realSize < size; realSize++) {
            if (!input_getc()) {
                break;
            }
        }
        lock_release(&(lockFile));
        return realSize;
    } else {
        struct file *fdF = getFile(fd);
        if (!fdF | !is_user_vaddr(buffer)) {
            lock_release(&(lockFile));
            return -1;
        }
        int ret = file_read(fdF, (void *)buffer, size);
        lock_release(&(lockFile));
        return ret;
    }
    lock_release(&(lockFile));

    return -1;
}
mapid_t mmap(int fd, void *addr) {
    mapid_t ret = -1;
    return ret;
}
void munmap(mapid_t mapping) { return; }
