#include "vm/swap.h"

#include "threads/synch.h"
#include "threads/vaddr.h"
struct bitmap* SwapBitmap;
struct block* SwapBlock;
// block_get_role
// - role 준걸로 역할 부여해서 블럭 줌 우리는 BLOCK_SWAP만 쓰면됨
// block_read
// - 해당 블럭에서 섹터번호 읽어서 버퍼에 뱉어줌
// block_write
// - 버퍼내용을 해당블럭의 섹터 번호에 써줌
// 이 세개만 알면 됨 ㅇㅅㅇ
// 스왑시 데이터 이동을 read / write로 구현하면되고
// 필요한 블럭은 get_role로 가져온다.
// 스왑스페이스 사용 가능여부에 대한 정보는
// 비트맵에 저장한다.
struct lock SwapLock;
// sys-wide변수들 제어 필요해서 lock
void init_SwapSpace(void) {
    // 구현
    SwapBitmap = bitmap_create(PGSIZE);
    if (!SwapBitmap) {
        PANIC("BITMAP NOT ALLOCATED");
        return;
    }
    bitmap_set_all(SwapBitmap, false);
    lock_init(&SwapLock);
}

void swap_in(void* kaddr, size_t idx) {
    // 디스크블럭의 idx에서 읽어서 가져옴
    // slot bitmap 변경 필요
    // printf("%p %d\n", kaddr, idx);
    SwapBlock = block_get_role(BLOCK_SWAP);
    if (!SwapBlock) {
        PANIC("BLAOCK NOT ALLOCATED");
    }
    lock_acquire(&SwapLock);
    if (idx >= 0 && bitmap_test(SwapBitmap, idx)) {
        int max_idx = PGSIZE / BLOCK_SECTOR_SIZE;
        for (int i = 0; i < max_idx; i++) {
            block_read(SwapBlock, idx * max_idx + i, kaddr + i * BLOCK_SECTOR_SIZE);
        }
        bitmap_set(SwapBitmap, idx, false);
    }
    lock_release(&SwapLock);
}
size_t swap_out(void* kaddr) {
    // 버릴 주소 받아서 해당놈을 디스크블럭으로 빼줌
    // 어디에 넣었는지 bitmap 변경 필요
    // 희생될 페이지 고르기
    // 만약 필요하다면 디스크에 쓰기
    SwapBlock = block_get_role(BLOCK_SWAP);
    if (!SwapBlock) {
        PANIC("BLOCK NOT ALLOCATED");
        return 0;
    }
    lock_acquire(&SwapLock);
    size_t idx = bitmap_scan_and_flip(SwapBitmap, 0, 1, false);
    if (idx == BITMAP_ERROR) {
        lock_release(&SwapLock);
        return 0;
    }
    int max_idx = PGSIZE / BLOCK_SECTOR_SIZE;

    for (int i = 0; i < max_idx; i++) {
        block_write(SwapBlock, idx * max_idx + i, kaddr + i * BLOCK_SECTOR_SIZE);
    }
    lock_release(&SwapLock);
    return idx;
}
