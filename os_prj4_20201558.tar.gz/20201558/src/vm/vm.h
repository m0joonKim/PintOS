#ifndef VM_VM_H
#define VM_VM_H
#include <hash.h>
#include <stddef.h>

#include "filesys/file.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
typedef enum { ELF, SWAP, MMAP } vm_type;
struct vm_entry {
    vm_type type;
    void* vaddr;
    bool writable;
    bool is_loaded;
    struct hash_elem h_elem;
    struct file* file;
    size_t offset;
    size_t read_bytes;
    size_t zero_bytes;
    size_t swap_stage_index;
};
bool init_vm(struct hash*);
void destroy_vm(struct hash*);
struct vm_entry* find_vme(struct hash* vm, void* vaddr);
struct vm_entry* make_vme(vm_type type, void* vaddr, bool writable, bool is_loadted, struct file* file, size_t offset, size_t read_bytes, size_t zero_bytes);
bool load_file(void* kaddr, struct vm_entry* vme);
bool delete_vme(struct hash* vm, struct vm_entry* vme);
bool make_and_insert_vme(struct thread* cur, vm_type type, void* vaddr, bool writable, bool is_loaded, struct file* file, size_t offset, size_t read_bytes, size_t zero_bytes);
#endif
