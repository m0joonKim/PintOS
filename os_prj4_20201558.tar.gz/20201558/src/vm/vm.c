#include "vm/vm.h"

#include <string.h>

#include "filesys/file.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "vm/frame.h"
#include "vm/swap.h"
static void delete_vm_func(struct hash_elem* a, void* UNUSED);
static unsigned hash_vm_func(struct hash_elem* a, void* UNUSED);
static bool cmp_vm_func(struct hash_elem* a, struct hash_elem* b, void* UNUSED);
bool init_vm(struct hash* vm) {  //
    bool result;
    if (result = hash_init(vm, hash_vm_func, cmp_vm_func, NULL)) {
        return true;
    } else {
        ASSERT(result);
        return false;
    }
}
void destroy_vm(struct hash* vm) {  //
    // 구현
    hash_destroy(vm, delete_vm_func);
}
bool delete_vme(struct hash* vm, struct vm_entry* vme) {
    if (!hash_delete(vm, &(vme->h_elem))) {
        return false;
    }
    delete_vm_func(&(vme->h_elem), NULL);
    return true;
}
bool make_and_insert_vme(struct thread* cur, vm_type type, void* vaddr, bool writable, bool is_loaded, struct file* file, size_t offset, size_t read_bytes, size_t zero_bytes) {
    struct hash* vm = &(cur->vm);
    struct vm_entry* vme = make_vme(type, vaddr, writable, is_loaded, file, offset, read_bytes, zero_bytes);
    if (!vme) {
        ASSERT(vme && vm);
        return false;
    } else {
        hash_insert(vm, &(vme->h_elem));
        return true;
    }
}
struct vm_entry* make_vme(vm_type type, void* vaddr, bool writable, bool is_loaded, struct file* file, size_t offset, size_t read_bytes, size_t zero_bytes) {
    struct vm_entry* new_vme;
    new_vme = (struct vm_entry*)malloc(sizeof(struct vm_entry));
    if (!new_vme) {
        return NULL;
    }
    memset(new_vme, 0, sizeof(struct vm_entry));
    new_vme->type = type;
    new_vme->vaddr = vaddr;
    new_vme->writable = writable;
    new_vme->is_loaded = is_loaded;
    new_vme->file = file;
    new_vme->offset = offset;
    new_vme->read_bytes = read_bytes;
    new_vme->zero_bytes = zero_bytes;
    return new_vme;
}
struct vm_entry* find_vme(struct hash* vm, void* vaddr) {
    // hash내에서 이 vaddr갖는 vm_entry찾기
    struct vm_entry temp_vme;
    temp_vme.vaddr = pg_round_down(vaddr);
    struct hash_elem* finder;
    finder = hash_find(vm, &(temp_vme.h_elem));
    return finder == NULL ? NULL : hash_entry(finder, struct vm_entry, h_elem);
}
static unsigned hash_vm_func(struct hash_elem* a, void* aux UNUSED) {
    struct vm_entry* entry = hash_entry(a, struct vm_entry, h_elem);
    unsigned ret = (unsigned)hash_int((int)(entry->vaddr));
    return ret;
}
static bool cmp_vm_func(struct hash_elem* a, struct hash_elem* b, void* aux UNUSED) {
    struct vm_entry* a_entry = hash_entry(a, struct vm_entry, h_elem);
    struct vm_entry* b_entry = hash_entry(b, struct vm_entry, h_elem);
    return ((a_entry->vaddr) < (b_entry->vaddr));
}
static void delete_vm_func(struct hash_elem* a, void* aux UNUSED) {
    struct vm_entry* entry = hash_entry(a, struct vm_entry, h_elem);
    struct thread* cur = thread_current();
    void* kaddr = pagedir_get_page(cur->pagedir, entry->vaddr);
    
    if(entry->is_loaded)free_frame(kaddr);
    free(entry);
    return;
}
bool load_file(void* kaddr, struct vm_entry* vme) {
    file_seek(vme->file, vme->offset);
    size_t read_bytes = vme->read_bytes;
    size_t real_read_bytes = (size_t)file_read(vme->file, kaddr, vme->read_bytes);
    if (read_bytes != real_read_bytes) return false;
    if (vme->zero_bytes == 0) {  // 다썼으면 끝
        return true;
    } else {  // 덜쓴건 채워주고 끝
        if (memset(kaddr + vme->read_bytes, 0, vme->zero_bytes)) return true;
    }
    NOT_REACHED();
    return false;
}
