#ifndef VM_SWAP_H
#define VM_SWAP_H
#include <bitmap.h>
#include <stddef.h>

#include "devices/block.h"
extern struct bitmap *swap_bitmap;

void init_SwapSpace(void);
void free_swap(size_t);
void swap_in(void *, size_t);
size_t swap_out(void *);
#endif