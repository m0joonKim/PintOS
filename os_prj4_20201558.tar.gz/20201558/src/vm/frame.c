#include "vm/frame.h"

#include "lib/string.h"
#include "threads/malloc.h"
#include "vm/swap.h"
struct list FrameTable;
struct lock FrameLock;
struct list_elem *FrameClock;
static void evict_frame(void);
static void remove_frame(struct frame *f);
void init_FrameTable(void) {
    // 구현
    FrameClock = NULL;
    list_init(&FrameTable);
    lock_init(&FrameLock);
    return;
}
static void remove_frame(struct frame *f) {
    struct list_elem *now = &(f->l_elem);
    struct list_elem *next = list_remove(&(f->l_elem));
    FrameClock = (now == FrameClock) ? next : FrameClock;
    return;
}
void free_frame(void *kaddr) {
    // 구현
    // kaddr갖는 놈 리스트에서 찾아서 죽이기
    lock_acquire(&FrameLock);
    struct list_elem *now = list_begin(&FrameTable);
    struct frame *finder = NULL;
    while (1) {
        if (now == list_end(&FrameTable)) {
            break;
        }
        if (list_entry(now, struct frame, l_elem)->kaddr == kaddr) {
            finder = list_entry(now, struct frame, l_elem);
            break;
        }
        now = list_next(now);
    }
    if (finder != NULL) {
        // 구현
        // remove에서 또 락을 잡을거기때문에 풀고 들어가야함
        remove_frame(finder);

        pagedir_clear_page(finder->thread->pagedir, finder->vme->vaddr);
        palloc_free_page(finder->kaddr);
        free(finder);
        lock_release(&FrameLock);

    } else {
        lock_release(&FrameLock);
    }
    return;
}

/* If there's a need for eviction of the frame, then search the unaccessed
   frame from the frame table with clock algorithm. After find it, then
   check the dirtiness of that frame and the type of the mapped PTE, and
   perform the corresponding routine for the dirtiness and the type.
   (Therefore, this routine uses an approximate LRU(Least Recently Used)
   algorithm) */

static void evict_frame(void) {
    // 누굴 빼낼지가 중요한데. clock을 권장하는듯함.
    //  clock 요약
    //  clock이 가리키는놈 ref bit 확인해서
    //  0이면 -> 교체대상. 새페이지 삽입하고 클락 다음으로
    //  1이면 -> 0으로 변경, 클락다음으로 가서 다시 확인
    //  즉 계속 돌면서 처음으로 0인놈 만날때까지 돌기
    struct frame *evictF = NULL;
    if (list_empty(&FrameTable)) return;
    while (1) {
        if ((FrameClock == NULL) || (FrameClock == list_end(&FrameTable))) {
            if (!list_empty(&FrameTable)) FrameClock = list_begin(&FrameTable);
        }
        FrameClock = list_next(FrameClock) == list_end(&FrameTable) ? list_begin(&FrameTable) : list_next(FrameClock);
        // 서큘러 리스트
        // 혹시 클락이 이상한데 가있거나 끝나있으면 첫놈으로 돌려주기
        struct frame *tmpF = list_entry(FrameClock, struct frame, l_elem);
        if (pagedir_is_accessed(tmpF->thread->pagedir, tmpF->vme->vaddr)) {
            pagedir_set_accessed(tmpF->thread->pagedir, tmpF->vme->vaddr, 0);
        } else {
            evictF = tmpF;
            break;
        }
    }
    ASSERT(evictF);
    bool dirtyBit = pagedir_is_dirty(evictF->thread->pagedir, evictF->vme->vaddr);
    vm_type type = evictF->vme->type;
    evictF->vme->is_loaded = false;
    if (type == SWAP) {
        evictF->vme->swap_stage_index = swap_out(evictF->kaddr);
    } else if (type == ELF && dirtyBit) {
        evictF->vme->swap_stage_index = swap_out(evictF->kaddr);
        evictF->vme->type = SWAP;
    }
    remove_frame(evictF);
    pagedir_clear_page(evictF->thread->pagedir, evictF->vme->vaddr);
    palloc_free_page(evictF->kaddr);
    free(evictF);
}
struct frame *alloc_get_page(enum palloc_flags flags) {
    // 하단의 함수르 대체할놈을 만들어야함.
    struct frame *retF;
    retF = (struct frame *)malloc(sizeof(struct frame));
    ASSERT(retF);
    if (!retF) return retF;
    memset(retF, 0, sizeof(struct frame));
    retF->kaddr = palloc_get_page(flags);  // 페이지 받아오는게실패했단느것은 evict필요함을 의미
    retF->thread = thread_current();
    // TODOTODO!!! evict 구현후 돌리기
    if (retF->kaddr == NULL) {
        lock_acquire(&FrameLock);
        evict_frame();
        lock_release(&FrameLock);
        retF->kaddr = palloc_get_page(flags);
    }
    lock_acquire(&FrameLock);
    list_push_back(&(FrameTable), &(retF->l_elem));
    lock_release(&FrameLock);
    return retF;
}
