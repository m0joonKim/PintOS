
#ifndef VM_FRAME_H
#define VM_FRAME_H
#include <list.h>

#include "threads/synch.h"
#include "threads/thread.h"
#include "vm/vm.h"
struct frame {
    void* kaddr;
    struct thread* thread;
    struct vm_entry* vme;
    struct list_elem l_elem;
};
void init_FrameTable(void);
void free_frame(void* kaddr);
struct frame* alloc_get_page(enum palloc_flags flags);

#endif