#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
int main(int argc, char *argv[])
{
    if (argc != 5)
    {
        printf("[ERROR] : argc is not 5\n");
        return EXIT_FAILURE;
    }
    int n1 = atoi(argv[1]);
    int n2 = atoi(argv[2]);
    int n3 = atoi(argv[3]);
    int n4 = atoi(argv[4]);
    printf("%d %d\n", fibonacci(n1), max_of_four_int(n1, n2, n3, n4));
    return EXIT_SUCCESS;
}
