#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
#include "devices/shutdown.h"
#include "devices/input.h"
static void syscall_handler(struct intr_frame *);

bool ValidAddressChecker(uint32_t *esp, int argc)
{
  for (int i = 0; i <= argc; i++)
  {
    if (!is_user_vaddr((void *)esp + i * 4) || is_kernel_vaddr((void *)esp + i * 4))
    {
      return false;
    }
  }
  return true;
}

void syscall_init(void)
{
  intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler(struct intr_frame *f UNUSED)
{
  uint32_t *SYSNUM = (uint32_t *)f->esp;
  if (!ValidAddressChecker(f->esp, 0))
    _exit(-1);
  // printf("\nnow sysnum is %d\n\n", *SYSNUM);
  switch (*SYSNUM)
  { // lib/user/syscall.c 보고 대충 구현하기
  case SYS_HALT:
    if (!ValidAddressChecker(f->esp, 0))
      _exit(-1);
    _halt();
    break;
  case SYS_EXIT:
    if (!ValidAddressChecker(f->esp, 1))
      _exit(-1);
    _exit(*(uint32_t *)(f->esp + 4));
    break;
  case SYS_EXEC:
    if (!ValidAddressChecker(f->esp, 1))
      _exit(-1);
    f->eax = _exec((const char *)*(uint32_t *)(f->esp + 4));
    break;
  case SYS_WAIT:
    if (!ValidAddressChecker(f->esp, 1))
      _exit(-1);
    f->eax = _wait((pid_t) * (uint32_t *)(f->esp + 4));
    break;
  case SYS_CREATE:
    break;
  case SYS_REMOVE:
    break;
  case SYS_OPEN:
    break;
  case SYS_FILESIZE:
    break;
  case SYS_READ:
    if (!ValidAddressChecker(f->esp, 3))
      _exit(-1);
    f->eax = _read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
    break;
  case SYS_WRITE:
    if (!ValidAddressChecker(f->esp, 3))
      _exit(-1);
    f->eax = _write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
    break;
  case SYS_SEEK:
    break;
  case SYS_TELL:
    break;
  case SYS_CLOSE:
    break;
  case SYS_FIBONACCI:
    if (!ValidAddressChecker(f->esp, 1))
      _exit(-1);
    f->eax = fibonacci((int)*(uint32_t *)(f->esp + 4));
    break;
  case SYS_MAXFOUR:
    if (!ValidAddressChecker(f->esp, 4))
      _exit(-1);
    f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
    break;
  default:
    break;
  }
}
void _halt()
{
  shutdown_power_off();
}
void _exit(int status)
{
  struct thread *nowthread = thread_current();
  nowthread->userprogStatus = status;
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_exit();
}
int _write(int fd, const void *buffer, unsigned size)
{
  if (fd == 1)
  {
    putbuf(buffer, size);
    return size;
  }
  return -1;
}
int _read(int fd, const void *buffer, unsigned size)
{
  unsigned int realSize = 0;
  if (fd == 0)
  {
    for (realSize = 0; realSize < size; realSize++)
    {
      if (!input_getc())
      {
        break;
      }
    }
    return realSize;
  }
  return -1;
}
int fibonacci(int n)
{
  if (n < 0)
  {
    printf("[ FIBONACCI ] N must be greater than 0\n");
    _exit(-1);
  }
  if (n == 0)
  {
    return 0;
  }
  if (n == 1)
  {
    return 1;
  }
  if (n == 2)
  {
    return 1;
  }
  int num1 = 1, num2 = 1, ret;
  for (int i = 3; i <= n; i++)
  {
    ret = num1 + num2;
    num1 = ret - num1;
    num2 = ret;
  }
  return ret;
}

int max_of_four_int(int n1, int n2, int n3, int n4)
{
  int ret = n1;
  if (ret < n2)
  {
    ret = n2;
  }
  if (ret < n3)
  {
    ret = n3;
  }
  if (ret < n4)
  {
    ret = n4;
  }
  return ret;
}
pid_t _exec(const char *cmd_line)
{
  // 이름으로부터 PID를 찾을수있음
  pid_t ret = process_execute(cmd_line);
  return ret;
}
int _wait(pid_t pid)
{
  int ret = process_wait(pid);
  // printf("wait ret is %d\n", ret);
  return ret;
}