#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
typedef int pid_t;
void syscall_init(void);
void _exit(int status);
int _write(int fd, const void *buffer, unsigned size);
void _halt(void);
int _read(int fd, const void *buffer, unsigned size);
int max_of_four_int(int n1, int n2, int n3, int n4);
int fibonacci(int n);
pid_t _exec(const char *cmd_lisne);
int _wait(pid_t pid);
#endif /* userprog/syscall.h */
