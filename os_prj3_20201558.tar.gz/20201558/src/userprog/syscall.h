#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>

#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/process.h"
typedef int pid_t;
struct file {
    struct inode *inode; /* File's inode. */
    off_t pos;           /* Current position. */
    bool deny_write;     /* Has file_deny_write() been called? */
};
void syscall_init(void);
struct file *getFile(int fd);
void _exit(int status);
int _write(int fd, const void *buffer, unsigned size);
void _halt(void);
int _read(int fd, const void *buffer, unsigned size);
int max_of_four_int(int n1, int n2, int n3, int n4);
int fibonacci(int n);
pid_t _exec(const char *cmd_lisne);
int _wait(pid_t pid);
bool _create(const char *file, unsigned initial_size);
bool _remove(const char *file);
int _open(const char *file);
int _filesize(int fd);
void _seek(int fd, unsigned position);
unsigned _tell(int fd);
void _close(int fd);

#endif /* userprog/syscall.h */
